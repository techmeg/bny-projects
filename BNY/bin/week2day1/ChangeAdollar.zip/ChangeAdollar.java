package week2day1;

import java.util.Scanner;

/*
 * author: Meg Parsons
 */
public class ChangeAdollar {

	public static void main(String[] args) {
		//Break a dollar amount into dollars and coins.
		System.out.println("Enter a dollar amount.");//get user input
		Scanner input = new Scanner(System.in);
		double amount = input.nextDouble();
		
		int dollar = (int)amount;//calculate each denomination
		amount = (amount - dollar) * 100;
		int quarter = (int)amount/25;
		amount = amount - (quarter * 25);
		int dimes = (int)amount/10;
		amount = amount - (dimes * 10);
		int nickels = (int) amount/5;
		amount  = amount - (nickels * 5);
		int pennies = (int)amount;
		
		//print resulting table
		System.out.println("Dollars\tQuarters\tDimes\tNickels\tPennies \n");
		System.out.println(dollar + "\t" + quarter + "\t\t" + dimes + "\t" + nickels + "\t" + pennies);
	}

}
